package file_Options;

import java.io.File;

public class TestFiles_List {

	public static void main(String[] args) {
		// List of folder available in the file path
		File file = new File("C:\\Users\\aravind\\Desktop\\Selenium_Class");
		String[] fileList = file.list();
		for(int i =0;i<fileList.length;i++) {
			System.out.println(fileList[i]);
		}

	}

}
