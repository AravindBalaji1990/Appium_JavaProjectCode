package absolutepathdemo;

import java.io.File;


public class RetireveAbsolutePath {

	public static void main(String[] args) {
		File file = new File("SampleInput.txt");
		String path = file.getAbsolutePath();
		System.out.println(path);
//		System.setProperty("webdriver.chrome.driver", path);
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://facebook.com");
//		System.out.println("the title :" +driver.getTitle());
//		driver.quit();

	}

}
