package interfacedemo;

public class TestClassB implements TestInterface1, TestInterface2 {

	public void testMethod1() {
		int result = 2 + 3;
		System.out.println("the result of addition :" + result);
	}

	@Override
	public int testMethod3() {
		return 100;
	}

	@Override
	public void methodAddition() {
		System.out.println("Adding method in testclassB");
	}

}
