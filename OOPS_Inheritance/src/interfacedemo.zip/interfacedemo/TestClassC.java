package interfacedemo;

public class TestClassC {

	public String print(String message) {
		return message;
	}

}
