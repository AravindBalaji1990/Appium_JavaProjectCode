package interfacedemo;

public interface TestInterface2 {
	public void methodAddition();

}
